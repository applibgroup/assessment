package com.sunbeam.test;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface ApiInterface {
    @GET("top-headlines")
    Call<ModelItems> getLatestNews(@Query("sources") String source,
                                              @Query("apiKey") String apiKey);
}
