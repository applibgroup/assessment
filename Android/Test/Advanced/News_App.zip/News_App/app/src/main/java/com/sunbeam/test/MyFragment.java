package com.sunbeam.test;


import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

//import com.android.volley.AuthFailureError;
//import com.android.volley.Request;
//import com.android.volley.RequestQueue;
//import com.android.volley.Response;
//import com.android.volley.VolleyError;
//import com.android.volley.toolbox.JsonObjectRequest;
//import com.android.volley.toolbox.StringRequest;
//import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Retrofit;
import retrofit2.Response;
import retrofit2.converter.gson.GsonConverterFactory;


public class MyFragment extends Fragment {
    private static final String LOG_TAG = MyFragment.class.getSimpleName();
    private static final String API_KEY = "9f8ce9efe35a4fa8ac661aa68e10492a";

    List <Article> items;
    ItemAdapter adapter;
    LinearLayoutManager layoutManager;
    RecyclerView recyclerView;

    int pos;
    public MyFragment() {

    }

    public MyFragment(int i) {
        this.pos = i;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        items = new ArrayList <>();
    }



    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.xmlfragment, container, false);
    }


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        recyclerView = getView().findViewById(R.id.recyclerView);
        layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);
        adapter = new ItemAdapter(getActivity(), items);
        recyclerView.setAdapter(adapter);

        String source;
        String urltemp;
        if (pos == 0) {
            urltemp = "https://newsapi.org/v2/top-headlines?sources=vice-news&apiKey=9f8ce9efe35a4fa8ac661aa68e10492a/";
            source = "vice-news";
        }
        else if(pos == 1)
        {urltemp = "https://newsapi.org/v2/top-headlines?sources=ary-news&apiKey=9f8ce9efe35a4fa8ac661aa68e10492a/";
            source = "ary-news";}
        else if(pos == 2)
        {urltemp = "https://newsapi.org/v2/top-headlines?sources=bbc-news&apiKey=9f8ce9efe35a4fa8ac661aa68e10492a/";
            source = "bbc-news";}
        else if(pos == 3) {
            urltemp = "https://newsapi.org/v2/top-headlines?sources=bbc-sport&apiKey=9f8ce9efe35a4fa8ac661aa68e10492a/";
            source = "bbc-sport";
        }
        else if(pos == 4)
        {urltemp = "https://newsapi.org/v2/top-headlines?sources=usa-today&apiKey=9f8ce9efe35a4fa8ac661aa68e10492a/";
            source = "usa-today";}
        else if(pos == 5)
        { urltemp = "https://newsapi.org/v2/top-headlines?sources=cnn&apiKey=9f8ce9efe35a4fa8ac661aa68e10492a/";
            source = "cnn";
        }
        else if(pos == 6)
        {urltemp = "https://newsapi.org/v2/top-headlines?sources=fox-news&apiKey=9f8ce9efe35a4fa8ac661aa68e10492a/";
            source = "fox-news";}
        else if(pos == 7)
        {urltemp = "https://newsapi.org/v2/top-headlines?sources=google-news&apiKey=9f8ce9efe35a4fa8ac661aa68e10492a/";
            source = "google-news";}
        else if(pos == 8)
        {urltemp = "https://newsapi.org/v2/top-headlines?sources=the-verge&apiKey=9f8ce9efe35a4fa8ac661aa68e10492a/";
            source = "the-verge";}
        else if(pos == 9)
        {urltemp = "https://newsapi.org/v2/top-headlines?sources=news24&apiKey=9f8ce9efe35a4fa8ac661aa68e10492a/";
            source = "news24";}
        else
        {
            urltemp = "https://newsapi.org/v2/top-headlines?sources=abc-news&apiKey=9f8ce9efe35a4fa8ac661aa68e10492a/";
            source = "abc-news";
        }

        /****************************************************/
        buildRetrofitView(urltemp, source);

        /****************************************************/

//
//        //creating a request queue
//        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
//
//        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest (Request.Method.GET, urltemp, null,
//                new Response.Listener<JSONObject>() {
//                    @Override
//                    public void onResponse(JSONObject response) {
//                        try {
//                            Log.d(LOG_TAG, "entered onResponse");
//                            Toast.makeText(getContext(),response.toString(),Toast.LENGTH_LONG).show();
//                            //getting the whole json object from the response
//
//                            //we have the array named tutorial inside the object
//                            //so here we are getting that json array
//                            JSONArray array = response.getJSONArray("articles");
//
//                            for (int i = 0; i < array.length(); i++) {
//                                JSONObject object = array.getJSONObject(i);
//
//                                String author = object.get("author").toString();
//
//                                String title = object.get("title").toString();
//                                title = title.substring(1, title.length() - 1);
//
//                                String url = object.get("url").toString();
//                                url = url.substring(1, url.length() - 1);
//
//                                String urlToImage = object.get("urlToImage").toString();
//                                urlToImage = urlToImage.substring(1, urlToImage.length() - 1);
//
//                                String date = object.get("publishedAt").toString();
//                                String content = object.get("content").toString();
//                                content = content.substring(1, content.length() - 1);
//
//                                items.add(new ModelItems(title, author, date, urlToImage, url));
//
//                            }
//
//                            Log.e("Harit", "success");
//
//                        }
//                        catch (JSONException e) {
//                            Log.e("Harit", "failure");
//                            e.printStackTrace();
//                        }
//                    }
//                },
//                new Response.ErrorListener() {
//                    @Override
//                    public void onErrorResponse(VolleyError error) {
//                        //displaying the error in toast if occur
////                        Toast.makeText(getContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
//                    }
//                }){
//
//            /**
//             * Passing some request headers
//             */
//            @Override
//            public Map<String, String> getHeaders() throws AuthFailureError {
//                HashMap<String, String> headers = new HashMap<String, String>();
//                headers.put("Content-Type", "application/json");
//                headers.put("key", "Value");
//                return headers;
//            }
//        };
//


//        //adding the string request to request queue
//        requestQueue.add(jsonObjectRequest);
//
//        adapter = new ItemAdapter(getActivity(), items);
//        recyclerView.setAdapter(adapter);
    }

    public void buildRetrofitView(String urltemp, String source){
        String baseurl = "https://newsapi.org/v2/";
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(baseurl)
                // on below line we are calling add
                // Converter factory as Gson converter factory.
                .addConverterFactory(GsonConverterFactory.create())
                // at last we are building our retrofit builder.
                .build();
        // below line is to create an instance for our retrofit api class.
        ApiInterface retrofitAPI = retrofit.create(ApiInterface.class);

        // on below line we are calling a method to get all the sources from API.
        Call<ModelItems> call = retrofitAPI.getLatestNews(source,API_KEY);

        call.enqueue(new Callback<ModelItems>() {
            @Override
            public void onResponse(Call<ModelItems> call, Response<ModelItems> response) {
                // inside on response method we are checking
                // if the response is success or not.
                if (response.isSuccessful()) {
                    Log.d(LOG_TAG, "inside onResponse");
                    // below line is to add our data from api to our array list.
                    List<Article> articleList = response.body().getArticles();

                    if(articleList!=null && articleList.size()>0) {
                        adapter = new ItemAdapter(getContext(), articleList);
                        recyclerView.setAdapter(adapter);
                    }
                }
            }

            @Override
            public void onFailure(Call<ModelItems> call, Throwable t) {
                // in the method of on failure we are displaying a
                // toast message for fail to get data.
                Log.d(LOG_TAG,"Failed: "+t.toString());
                Toast.makeText(getContext(), "Failed to get data", Toast.LENGTH_SHORT).show();
            }
        });
    }

}

