package com.example.splashscreen;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.splashscreen.ui.login.LoginActivity;

public class MainActivity2 extends AppCompatActivity {

    public void prevPage2(View view){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
   public void nextPage2(View view){
       Intent intent = new Intent(this, MainActivity3.class);
       startActivity(intent);
   }
   public void skipPage2(View view){
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        //Intent intent = getIntent();
    }
}