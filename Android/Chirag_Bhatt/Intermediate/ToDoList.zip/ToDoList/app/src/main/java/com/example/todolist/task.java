package com.example.todolist;

public class task {
    private  String task_name = null;
    private  String task_desc = null;
    private  String task_date = null;
    private String task_time = null;
    private String docId = null;
    public task(){
    }
    public task(String a, String b, String c, String d){
        this.task_name = a;
        this.task_desc = b;
        this.task_date = c;
        this.task_time = d;
    }

    public String getTask_name() {
        return task_name;
    }

    public String getTask_desc() {
        return task_desc;
    }
    public String getTask_date() {
        return task_date;
    }

    public String getTask_time() {
        return task_time;
    }

    public void setTask_name(String task_name) {
        this.task_name = task_name;
    }

    public void setTask_desc(String task_desc) {
        this.task_desc = task_desc;
    }

    public void setTask_date(String task_date) {
        this.task_date = task_date;
    }

    public void setTask_time(String task_time) {
        this.task_time = task_time;
    }

    public String getDocId() {
        return docId;
    }

    public void setDocId(String docId) {
        this.docId = docId;
    }

    @Override
    public String toString() {
        String s = task_name;
        if(task_date != null)
            s = s + " " + task_date;
        if(task_time != null)
            s = s + " " + task_time;
        return s;
    }

}

