package com.example.todolist;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;


import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {
    ListView listView;
    ArrayList<task> task_list;
    ArrayAdapter<task> arrayAdapter;

    FirebaseFirestore database;
    CollectionReference db;
    DocumentReference dr;

    private task newT;
    private AlertDialog.Builder dialogBuilder;
    private AlertDialog dialog;
    private EditText task_text, desc_text, date, time;
    private Button addTask, back, deleteTask, save;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        database = FirebaseFirestore.getInstance();
        db = database.collection("task");
        dr = db.document();

        task_list = new ArrayList<task>();
        listView = findViewById(R.id.taskList);
        arrayAdapter = new ArrayAdapter<task>(getApplicationContext(), android.R.layout.simple_list_item_1, task_list);
        listView.setAdapter(arrayAdapter);
        db.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if(task.isSuccessful()){
                    for(QueryDocumentSnapshot document : Objects.requireNonNull(task.getResult())) {
                        task t = document.toObject(task.class);
                        task_list.add(t);
                    }
                    listView.setAdapter(arrayAdapter);

                } else {
                    Log.d("Getting Task", "Error getting tasks: ", task.getException());
                }
            }
        });
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view,int position, long id){
                openTask(task_list.get(position), position);
            }
        });
    }

    public void openTask(task t, int position) {
        dialogBuilder = new AlertDialog.Builder(this);
        final View taskView = getLayoutInflater().inflate(R.layout.task_popup, null);

        task_text = taskView.findViewById(R.id.task_text);
        task_text.setText(t.getTask_name());

        desc_text = taskView.findViewById(R.id.desc_task);
        if (t.getTask_desc() != null)
            desc_text.setText(t.getTask_desc());

        date = taskView.findViewById(R.id.taskDate);
        if (t.getTask_date() != null)
            date.setText(t.getTask_date());

        time = taskView.findViewById(R.id.taskTime);
        if (t.getTask_time() != null)
            time.setText(t.getTask_time());

        deleteTask = taskView.findViewById(R.id.deleteButton);
        save = taskView.findViewById(R.id.saveButton);
        back = taskView.findViewById(R.id.backButton);
        dialogBuilder.setView(taskView);
        dialog = dialogBuilder.create();
        dialog.show();

        deleteTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                task_list.remove(position);
                listView.setAdapter(arrayAdapter);
                arrayAdapter.notifyDataSetChanged();
                db.document(t.getDocId()).delete()
                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Toast.makeText(MainActivity.this,"DocumentSnapshot successfully deleted!",Toast.LENGTH_SHORT).show();
                        }
                    });
                dialog.dismiss();
            }
        });
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String newTask = ((EditText) taskView.findViewById(R.id.task_text)).getText().toString();
                String newDesc = ((EditText) taskView.findViewById(R.id.desc_task)).getText().toString();
                String newDate = ((EditText) taskView.findViewById(R.id.taskDate)).getText().toString();
                String newTime = ((EditText) taskView.findViewById(R.id.taskTime)).getText().toString();
                newT = new task(newTask,newDesc,newDate,newTime);

                if (!newTask.trim().isEmpty()) {
                    task t = task_list.get(position);
                    t.setTask_name(newTask);
                    t.setTask_desc(newDesc);
                    t.setTask_date(newDate);
                    t.setTask_time(newTime);
                    newT.setDocId(t.getDocId());
                    db.document(t.getDocId()).set(newT)
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            // on successful completion of this process
                            // we are displaying the toast message.
                            Toast.makeText(MainActivity.this, "Task saved successfully", Toast.LENGTH_SHORT).show();
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        // inside on failure method we are
                        // displaying a failure message.
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(MainActivity.this, "Failed to save the changes", Toast.LENGTH_SHORT).show();
                        }
                    });


                    listView.setAdapter(arrayAdapter);
                    arrayAdapter.notifyDataSetChanged();
                }
                else{
                    Toast.makeText(MainActivity.this,"Task can not have empty task name", Toast.LENGTH_SHORT).show();
                }
                dialog.dismiss();
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
    }

    public void addNewTask(View v) {
        dialogBuilder = new AlertDialog.Builder(this);
        final View add_popup = getLayoutInflater().inflate(R.layout.add_popup, null);
        task_text = add_popup.findViewById(R.id.task_text);
        desc_text = add_popup.findViewById(R.id.desc_add);
        date = add_popup.findViewById(R.id.addDate);
        time = add_popup.findViewById(R.id.addTime);

        addTask = add_popup.findViewById(R.id.deletButton);
        back = add_popup.findViewById(R.id.backButton);
        dialogBuilder.setView(add_popup);
        dialog = dialogBuilder.create();
        dialog.show();

        addTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String newTaskName = task_text.getText().toString();
                String newTaskDesc = desc_text.getText().toString();
                String newDate = date.getText().toString();
                String newTime = time.getText().toString();
                System.out.println(newTaskName);
                System.out.println((newTaskDesc));
                if (!newTaskName.trim().isEmpty()) {
                    newT = new task(newTaskName,newTaskDesc,newDate,newTime);
                    db.add(newT).addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                        @Override
                        public void onSuccess(DocumentReference documentReference) {
                            String dId = documentReference.getId();
                            newT.setDocId(dId);
                            db.document(dId).set(newT);
                            // after the data addition is successful
                            // we are displaying a success toast message.
                            Toast.makeText(MainActivity.this, "Task added successfully", Toast.LENGTH_SHORT).show();
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            // this method is called when the data addition process is failed.
                            // displaying a toast message when data addition is failed.
                            Toast.makeText(MainActivity.this, "Failed to add task\n" + e, Toast.LENGTH_SHORT).show();
                        }
                    });

                    task_list.add(newT);
                    listView.setAdapter(arrayAdapter);
                    arrayAdapter.notifyDataSetChanged();
                    //db.document().set(newT);
                }
                else{
                    Toast.makeText(MainActivity.this,"Can not create task with empty task name", Toast.LENGTH_SHORT).show();
                }
                dialog.dismiss();
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
    }

}
