package com.example.headlines;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.List;

public class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder> {
    List<Article> articleList;
    Context context;



    public Adapter(List<Article> articleList, Context c) {
        this.articleList = articleList;
        this.context = c;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.news, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.title.setText(articleList.get(position).getTitle());
        Source s = articleList.get(position).getSource();
        holder.src.setText(s.getName());
        String split_date = articleList.get(position).getPublishedAt();
        String[] parts = split_date.split("T");
        String final_string = parts[0] + "  " + parts[1].substring(0, parts[1].length() - 1);
        holder.date.setText(final_string);

        Picasso.get().load(articleList.get(position).getUrlToImage()).into(holder.image);

    }

    @Override
    public int getItemCount() {
        return articleList.size();
    }

    public void addArticles(List<Article> articles) {
        this.articleList.addAll(articles);
        int count = getItemCount();
        notifyDataSetChanged();
    }



    public class ViewHolder extends RecyclerView.ViewHolder  implements View.OnClickListener{
        private TextView title, src, date;
        private ImageView image;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            itemView.setOnClickListener(this);
            context = itemView.getContext();
            title = itemView.findViewById(R.id.newsTitle);
            src = itemView.findViewById(R.id.newsSource);
            date = itemView.findViewById(R.id.newsDate);
            image = itemView.findViewById(R.id.imageView);
        }

        @Override
        public void onClick(View view) {
            Log.d("ClickFromViewHolder", "Clicked");
            int position = this.getLayoutPosition();
            Article article = articleList.get(position);
            String title = article.getTitle();
            String desc = article.getDescription();
            Source source = article.getSource();
            String src = source.getName();
            String ImageURL = article.getUrlToImage();
            String author = article.getAuthor();
            String newsURL = article.getUrl();
            String split_date = articleList.get(position).getPublishedAt();
            String[] parts = split_date.split("T");
            String newsDate = parts[0] + "  " + parts[1].substring(0, parts[1].length() - 1);


            Intent intent = new Intent(context, DisplayNews.class);
            intent.putExtra("Title", title);
            intent.putExtra("Desc", desc);
            intent.putExtra("Source", src);
            intent.putExtra("ImageURL",ImageURL);
            intent.putExtra("newsURL",newsURL);
            intent.putExtra("newsDate",newsDate);
            intent.putExtra("newsAuthor",author);
            context.startActivity(intent);

        }


    }

}
