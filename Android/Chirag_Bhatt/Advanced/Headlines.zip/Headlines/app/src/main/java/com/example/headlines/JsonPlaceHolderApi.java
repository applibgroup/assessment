package com.example.headlines;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface JsonPlaceHolderApi {
   // @GET("posts")
   // Call<List<Post>> getPosts();
    @GET("top-headlines")
    Call<com.example.headlines.News> get_Country_News(@Query("language") String lang, @Query("country") String country, @Query("apiKey") String apiKey);
    @GET("top-headlines")
    Call<com.example.headlines.News> get_Category_News(@Query("language") String lang, @Query("category") String category, @Query("apiKey") String apiKey);
}
