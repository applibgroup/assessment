package com.example.headlines;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.squareup.picasso.Picasso;

public class DisplayNews extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_news);
        Intent intent = getIntent();
        String title = intent.getStringExtra("Title");
        String desc = intent.getStringExtra("Desc");
        String src = intent.getStringExtra("Source");
        String imageURL = intent.getStringExtra("ImageURL");
        String newsURL = intent.getStringExtra("newsURL");
        String newsDate = intent.getStringExtra("newsDate");
        String newsAuthor = intent.getStringExtra("newsAuthor");

        TextView titleTextView = findViewById(R.id.displayNewsTitle);
        titleTextView.setText(title);


        TextView descTextView = findViewById(R.id.displayNewsDesc);
        descTextView.setText(desc);

        ImageView img = findViewById(R.id.Image);
        Picasso.get().load(imageURL).into(img);

        TextView srcTextView = findViewById(R.id.displayNewsSrc);
        srcTextView.setText(src);

        TextView dateTextView = findViewById(R.id.displayNewsDate);
        dateTextView.setText(newsDate);

        TextView authorTextView = findViewById(R.id.newsAuthor);
        authorTextView.setText(newsAuthor);

        TextView urlTextView = findViewById(R.id.newsURL);
        urlTextView.setText(newsURL);


    }

}

