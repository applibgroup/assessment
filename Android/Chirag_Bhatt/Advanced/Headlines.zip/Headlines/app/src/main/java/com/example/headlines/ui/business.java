package com.example.headlines.ui;

import androidx.lifecycle.ViewModelProvider;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.headlines.Adapter;
import com.example.headlines.Article;
import com.example.headlines.JsonPlaceHolderApi;
import com.example.headlines.News;
import com.example.headlines.R;
import com.example.headlines.RetrofitClient;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class business extends Fragment {

    private RecyclerView recyclerView;
    private List<Article> articleList;
    private Adapter mainArticleAdapter;

    private String APIKey = "2b75d7dbf7e942cb9a9f22d33b22ef06";
    private String baseURL = "https://newsapi.org/v2/";
    private String category = "business";

    public static business newInstance() {
        return new business();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {


        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.business_fragment, container, false);
        articleList = new ArrayList<>();
        load_business_data();

        recyclerView = view.findViewById(R.id.business_fragment);;
        recyclerView.setHasFixedSize(true);

        final LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(linearLayoutManager);


        return view;

    }
    private void load_business_data(){
        Retrofit retrofit = null;
        retrofit = RetrofitClient.getClient1(baseURL);
        JsonPlaceHolderApi jsonPlaceHolderApi = retrofit.create(JsonPlaceHolderApi.class);
        Call<News> call = jsonPlaceHolderApi.get_Category_News("en",category,APIKey);
        call.enqueue(new Callback<News>() {
            @Override
            public void onResponse(Call<News> call, Response<News> response) {
                if (!response.isSuccessful()) {
                    Toast.makeText(getActivity(),"Failed to load news",Toast.LENGTH_SHORT);
                    return;
                }
                News news = response.body();
                articleList = news.getArticles();
                mainArticleAdapter = new Adapter(articleList, getActivity());
                recyclerView.setAdapter(mainArticleAdapter);
            }

            @Override
            public void onFailure(Call<News> call, Throwable t) {
                Toast.makeText(getActivity(),"Failed to load news",Toast.LENGTH_SHORT);
            }
        });

    }

}
