package com.example.onestoplogin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.CallbackManager;
import com.facebook.GraphRequest;
import com.facebook.ProfileTracker;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FacebookAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.squareup.picasso.Picasso;

import org.json.JSONException;

public class Profile extends AppCompatActivity {

    private ImageView image;
    private TextView name, email, phone;
    private Button signOutBtn;

    public GoogleSignInClient mGoogleSignInClient;
    private FirebaseAuth mAuth;
    FirebaseUser currentUser ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        image = (ImageView)findViewById(R.id.profile_image);
        name = (TextView)findViewById(R.id.profile_name);
        email = (TextView)findViewById(R.id.profile_email);
        phone = (TextView)findViewById(R.id.profile_number);
        signOutBtn = (Button)findViewById(R.id.button);

        Intent intent = getIntent();
        name.setText( intent.getStringExtra("Name"));
        email.setText(intent.getStringExtra("Email"));
        phone.setText(intent.getStringExtra("Number"));

        Picasso.get().load(intent.getStringExtra("PhotoUrl")).placeholder(R.mipmap.ic_launcher).into(image);
//        Log.d("DEBUG", name.getText().toString());
//        Log.d("DEBUG", email.getText().toString());
//        Log.d("DEBUG", intent.getStringExtra("PhotoUrl"));

        signOutBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                        .requestIdToken(getString(R.string.default_web_client_id))
                        .requestEmail()
                        .build();

                mGoogleSignInClient = GoogleSignIn.getClient(Profile.this, gso);
                mGoogleSignInClient.signOut().addOnCompleteListener(Profile.this, new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        FirebaseAuth.getInstance().signOut();
                        LoginManager.getInstance().logOut();
                        startActivity(new Intent(Profile.this, MainActivity.class));
                        finish();
                    }
                });

            }
        });
    }

    @Override
    public void onStart() {
        super.onStart();
//        FirebaseUser currentUser = mAuth.getCurrentUser();
//        if (currentUser != null) {
//            name.setText(currentUser.getDisplayName());
//            email.setText(currentUser.getEmail());
//            Picasso.get().load(currentUser.getPhotoUrl()).placeholder(R.mipmap.ic_launcher).into(image);
//        }
    }

}