package com.example.harmonyassignment1.slice;

import ohos.aafwk.ability.AbilitySlice;
import com.example.harmonyassignment1.ResourceTable;
import ohos.aafwk.content.Intent;

public class SignUpAbilitySlice extends AbilitySlice {
    @Override
    protected void onStart(Intent intent) {
        super.onStart(intent);
        setUIContent(ResourceTable.Layout_ability_slice_signup);
    }
}
