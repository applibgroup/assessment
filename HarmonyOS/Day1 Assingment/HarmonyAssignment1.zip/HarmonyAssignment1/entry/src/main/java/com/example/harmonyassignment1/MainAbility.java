package com.example.harmonyassignment1;

import ohos.ace.ability.AceAbility;
import ohos.aafwk.content.Intent;
import com.example.harmonyassignment1.slice.MainAbilitySlice;

public class MainAbility extends AceAbility {
    @Override
    public void onStart(Intent intent) {
        super.onStart(intent);
        super.setMainRoute(MainAbilitySlice.class.getName());
    }

    @Override
    public void onStop() {
        super.onStop();
    }
}
