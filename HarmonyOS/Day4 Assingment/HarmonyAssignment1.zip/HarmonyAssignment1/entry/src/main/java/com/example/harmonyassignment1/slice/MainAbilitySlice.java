package com.example.harmonyassignment1.slice;

import com.example.harmonyassignment1.ResourceTable;
import ohos.aafwk.ability.AbilitySlice;
import ohos.agp.animation.Animator;
import ohos.agp.animation.AnimatorProperty;
import ohos.agp.components.Button;
import ohos.agp.components.Component;
import ohos.agp.components.Image;
import ohos.aafwk.content.Intent;
import ohos.hiviewdfx.HiLog;
import ohos.hiviewdfx.HiLogLabel;

public class MainAbilitySlice extends AbilitySlice{
    private Image pic;
    private Button login_button;
    private Button signup_button;
    private AnimatorProperty animatorProperty;
    private static final HiLogLabel LABEL = new HiLogLabel(HiLog.LOG_APP, 0x00201, "MY_TAG");

    @Override
    public void onStart(Intent intent) {
        super.onStart(intent);
        super.setUIContent(ResourceTable.Layout_ability_main);

        pic = (Image) findComponentById(ResourceTable.Id_image);
        login_button = (Button) findComponentById(ResourceTable.Id_login);
        signup_button = (Button) findComponentById(ResourceTable.Id_signup);

        pic.setPixelMap(ResourceTable.Media_Tesla_T_symbol);
        pic.setScaleMode(Image.ScaleMode.STRETCH);
        animatorProperty = pic.createAnimatorProperty();
        animate(pic);

        pic.setClickedListener(component -> animatorProperty.start());
        login_button.setClickedListener( component -> present(new LoginAbilitySlice(), new Intent()));
        signup_button.setClickedListener(component -> present(new SignUpAbilitySlice(), new Intent()));

    }

    private void animate(Image pic) {
        animatorProperty.moveFromX(-10).moveToX(1000).rotate(90).alpha(0)
                .setDuration(2500).setDelay(500).setLoopedCount(3);

        animatorProperty.setStateChangedListener(new Animator.StateChangedListener() {
            @Override
            public void onStart(Animator animator) {
            }

            @Override
            public void onStop(Animator animator) {
            }

            @Override
            public void onCancel(Animator animator) {
            }

            @Override
            public void onEnd(Animator animator) {
                animatorProperty.reset();
            }

            @Override
            public void onPause(Animator animator) {
            }

            @Override
            public void onResume(Animator animator) {

            }
        });

        pic.setBindStateChangedListener(new Component.BindStateChangedListener() {
            @Override
            public void onComponentBoundToWindow(Component component) {
                animatorProperty.start();
            }

            @Override
            public void onComponentUnboundFromWindow(Component component) {
                animatorProperty.stop();
            }
        });
    }

    @Override
    public void onActive() {
        super.onActive();
    }

    @Override
    public void onForeground(Intent intent) {
        super.onForeground(intent);
    }

    @Override
    protected void onBackground() { super.onBackground();
    }
}

