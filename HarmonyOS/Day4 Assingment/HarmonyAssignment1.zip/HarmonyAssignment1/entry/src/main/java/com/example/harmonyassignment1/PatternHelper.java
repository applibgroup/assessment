package com.example.harmonyassignment1;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PatternHelper {
    private static final String PATTERN_NUMBER_REGEX = ".*\\d.*";
    private static final String PATTERN_SPECIAL_CHAR = "[^a-zA-Z0-9]";
    private static final String PATTERN_NUMBER = "[^0-9]";

    public PatternHelper() {
    }

    public static boolean hasNumber(String string) {
        return string.matches(PATTERN_NUMBER_REGEX);
    }

    public static boolean hasSpecialCharacter(String string) {
        Pattern pattern = Pattern.compile(PATTERN_SPECIAL_CHAR);
        Matcher matcher = pattern.matcher(string);
        return matcher.find();
    }

    public static boolean hasOnlyNumber(String string) {
        Pattern pattern = Pattern.compile(PATTERN_NUMBER);
        Matcher matcher = pattern.matcher(string);
        return !matcher.find();
    }
}
