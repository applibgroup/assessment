package com.example.harmonyassignment1.slice;

import com.example.harmonyassignment1.MyDatabase;
import com.example.harmonyassignment1.User;
import ohos.aafwk.ability.AbilitySlice;
import ohos.aafwk.content.Intent;
import com.example.harmonyassignment1.ResourceTable;
import ohos.agp.components.Button;
import ohos.agp.components.Component;
import ohos.agp.components.Text;
import ohos.agp.window.dialog.ToastDialog;
import ohos.data.DatabaseHelper;
import ohos.data.orm.OrmContext;
import ohos.data.orm.OrmPredicates;

import java.util.List;

public class HomePageAbilitySlice extends AbilitySlice {
    Text welcome_msg;
    OrmContext ormContext;
    @Override
    protected void onStart(Intent intent) {
        super.onStart(intent);
        super.setUIContent(ResourceTable.Layout_ability_slice_homepage);

        welcome_msg = (Text) findComponentById(ResourceTable.Id_welcome_text);
        String firstName = intent.getStringParam("firstName");
        String lastName = intent.getStringParam("lastName");

        welcome_msg.setText("Welcome, "+firstName+" "+lastName);

        DatabaseHelper databaseHelper = new DatabaseHelper(this);
        ormContext = databaseHelper.getOrmContext("MyDatabase", "MyDatabase.db", MyDatabase.class);
    }

    @Override
    protected void onBackPressed() {
        super.onBackPressed();
    }

}
