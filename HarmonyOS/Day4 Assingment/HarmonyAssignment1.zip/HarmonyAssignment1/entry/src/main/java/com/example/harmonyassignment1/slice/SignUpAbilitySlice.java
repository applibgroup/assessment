package com.example.harmonyassignment1.slice;

import com.example.harmonyassignment1.*;
import ohos.aafwk.ability.AbilitySlice;
import ohos.aafwk.content.Intent;
import ohos.agp.components.*;
import ohos.agp.window.dialog.ToastDialog;
import ohos.data.DatabaseHelper;
import ohos.data.orm.OrmContext;
import ohos.data.orm.OrmPredicates;

import java.util.List;


public class SignUpAbilitySlice extends AbilitySlice {
    TextField firstName;
    TextField lastName;
    TextField emailField;
    TextField passwordField;
    TextField mobileField;
    RadioButton maleButton;
    RadioButton femaleButton;
    Text firstNameError;
    Text lastNameError;
    Text emailError;
    Text passwordError;
    Text mobileError;
    Button register;
    PatternHelper adapter;
    private OrmContext ormContext;

    @Override
    protected void onStart(Intent intent) {
        super.onStart(intent);
        setUIContent(ResourceTable.Layout_ability_slice_signup);

        firstName = (TextField) findComponentById(ResourceTable.Id_first_name_field);
        lastName = (TextField) findComponentById(ResourceTable.Id_last_name_field);
        emailField = (TextField) findComponentById(ResourceTable.Id_email);
        passwordField = (TextField) findComponentById(ResourceTable.Id_password);
        mobileField = (TextField) findComponentById(ResourceTable.Id_mobile);

        firstNameError = (Text) findComponentById(ResourceTable.Id_firstname_error);
        lastNameError = (Text) findComponentById(ResourceTable.Id_lastname_error);
        emailError = (Text) findComponentById(ResourceTable.Id_email_error);
        passwordError = (Text) findComponentById(ResourceTable.Id_password_error);
        mobileError = (Text) findComponentById(ResourceTable.Id_mobile_error);

        maleButton = (RadioButton) findComponentById(ResourceTable.Id_gender_male);
        femaleButton = (RadioButton) findComponentById(ResourceTable.Id_gender_female);

        register = (Button) findComponentById(ResourceTable.Id_signup_btn);

        firstName.addTextObserver((input,start,before, count)-> validateName(firstNameError,input));
        lastName.addTextObserver((input, start, before, count)-> validateName(lastNameError,input));
        emailField.addTextObserver((input, start, before, count) -> validateEmail(input));
        passwordField.addTextObserver((input, start, before, count) -> validatePassword(input));
        mobileField.addTextObserver((input, start, before, count) -> validateMobile(input));
        register.setClickedListener(component -> handleSubmitClick(component));

        adapter = new PatternHelper();

        DatabaseHelper databaseHelper = new DatabaseHelper(this);
        ormContext = databaseHelper.getOrmContext("MyDatabase", "MyDatabase.db", MyDatabase.class);
    }

    @Override
    protected void onBackPressed() {
        super.onBackPressed();
    }

    private void handleSubmitClick(Component component) {
        ToastDialog toastDialog = new ToastDialog(component.getContext());
        if (firstName.getText() == null
                || lastName.getText() == null
                || emailField.getText() == null
                || passwordField.getText() == null
                || mobileField.getText() == null
                || firstName.getText().isEmpty()
                || lastName.getText().isEmpty()
                || emailField.getText().isEmpty()
                || mobileField.getText().isEmpty()) {
            toastDialog.setText(component.getContext().getString(ResourceTable.String_submit_error)).show();
        } else if (firstNameError.getVisibility() == Component.VISIBLE
                || lastNameError.getVisibility() == Component.VISIBLE
                || emailError.getVisibility() == Component.VISIBLE
                || passwordError.getVisibility() == Component.VISIBLE
                || mobileError.getVisibility() == Component.VISIBLE) {
            toastDialog.setText(component.getContext().getString(ResourceTable.String_submit_error)).show();
        } else if (!maleButton.isChecked() && !femaleButton.isChecked()) {
            toastDialog.setText(component.getContext().getString(ResourceTable.String_error_select_gender)).show();
        } else {
            User user = new User();
            user.setEmail(emailField.getText());
            user.setPassword(passwordField.getText());
            user.setFirstName(firstName.getText());
            user.setLastName(lastName.getText());
            user.setMobileNumber(mobileField.getText());
            user.setGender(maleButton.isChecked() ? "M" : "F");

            if (canInsertUser(user)) {
                insertUser(user);
                toastDialog.setText(component.getContext().getString(ResourceTable.String_submit_success)).show();

                Intent intent = new Intent();
                intent.setParam("firstName", user.getFirstName());
                intent.setParam("lastName", user.getLastName());
                present(new HomePageAbilitySlice(), intent);
            } else {
                toastDialog.setText(component.getContext().getString(ResourceTable.String_submit_account_exist_error)).show();
            }
        }
    }

    private void insertUser(User user) {
        ormContext.insert(user);
        ormContext.flush();
    }

    private boolean canInsertUser(User user) {
        OrmPredicates ormPredicates = ormContext.where(User.class);
        ormPredicates.equalTo("email", user.getEmail());
        List<User> users = ormContext.query(ormPredicates);
        if (users == null || users.size() == 0) {
            return true;
        }
        return false;
    }

    private void validateMobile(String input) {
        if(input==null || input.isEmpty()){
            return;
        }
        else if(input.length()<10 || !adapter.hasOnlyNumber(input)){
            mobileError.setVisibility(Component.VISIBLE);
        }
        else{
            mobileError.setVisibility(Component.HIDE);
        }
    }

    private void validatePassword(String input) {
        if (input==null){
            return;
        }
        else if(input.length()<5){
            passwordError.setVisibility(Component.VISIBLE);
        }
        else{
            passwordError.setVisibility(Component.HIDE);
        }
    }

    private void validateEmail(String input) {
        if (input==null){
            return;
        }
        else if(!input.contains("@") || !input.contains(".com")){
            emailError.setVisibility(Component.VISIBLE);
        }
        else{
            emailError.setVisibility(Component.HIDE);
        }
    }

    private void validateName(Text error_text, String input) {
        if (input==null){
            return;
        }
        else if(adapter.hasSpecialCharacter(input) || adapter.hasNumber(input)){
            error_text.setVisibility(Component.VISIBLE);
        }
        else{
            error_text.setVisibility(Component.HIDE);
        }
    }

}
