package com.example.harmonyassignment1;

import ohos.data.orm.OrmDatabase;
import ohos.data.orm.annotation.Database;

@Database(entities = {User.class}, version = 1)
public abstract class MyDatabase extends OrmDatabase {
}
