package com.example.harmonyassignment1.slice;

import com.example.harmonyassignment1.MyDatabase;
import com.example.harmonyassignment1.User;
import ohos.aafwk.ability.AbilitySlice;
import ohos.aafwk.content.Intent;
import com.example.harmonyassignment1.ResourceTable;
import ohos.agp.components.Button;
import ohos.agp.components.Component;
import ohos.agp.components.Text;
import ohos.agp.components.TextField;
import ohos.agp.window.dialog.ToastDialog;
import ohos.data.DatabaseHelper;
import ohos.data.orm.OrmContext;
import ohos.data.orm.OrmPredicates;

import java.util.List;


public class LoginAbilitySlice extends AbilitySlice {
    private TextField emailField;
    private Text emailError;
    private TextField passwordField;
    private Button loginBtn;
    private OrmContext ormContext;

    @Override
    protected void onStart(Intent intent) {
        super.onStart(intent);
        setUIContent(ResourceTable.Layout_ability_slice_login);

        emailField = (TextField) findComponentById(ResourceTable.Id_login_email);
        emailError = (Text) findComponentById(ResourceTable.Id_login_email_error);
        passwordField = (TextField) findComponentById(ResourceTable.Id_login_password);
        loginBtn = (Button) findComponentById(ResourceTable.Id_login_btn);

        if (intent!=null) {
            String email = intent.getStringParam("email");
            String password = intent.getStringParam("password");
            emailField.setText(email);
            passwordField.setText(password);
        }

        DatabaseHelper databaseHelper = new DatabaseHelper(this);
        ormContext = databaseHelper.getOrmContext("MyDatabase", "MyDatabase.db", MyDatabase.class);

        emailField.addTextObserver((input, start, before, count) -> validateEmail(input));
        loginBtn.setClickedListener(component -> handleLogin(component));
    }

    @Override
    protected void onBackPressed() {
        super.onBackPressed();
    }

    private void handleLogin(Component component) {
        ToastDialog toastDialog = new ToastDialog(component.getContext());

        if (emailField.getText() == null
                || passwordField.getText() == null
                || emailField.getText().isEmpty()
                || passwordField.getText().isEmpty()) {
            toastDialog.setText(component.getContext().getString(ResourceTable.String_login_error_empty_fields)).show();
        } else if (emailError.getVisibility() == Component.VISIBLE) {
            toastDialog.setText(component.getContext().getString(ResourceTable.String_login_error_invalid_email)).show();
        } else {
            OrmPredicates ormPredicates = ormContext.where(User.class);
            ormPredicates.equalTo("email", emailField.getText());
            ormPredicates.and();
            ormPredicates.equalTo("password", passwordField.getText());
            List<User> users = ormContext.query(ormPredicates);
            if (users == null || users.isEmpty()) {
                toastDialog.setText(component.getContext().getString(ResourceTable.String_login_error_invalid_credentials)).show();
            } else {
                toastDialog.setText(component.getContext().getString(ResourceTable.String_login_success)).show();
                Intent intent = new Intent();
                intent.setParam("firstName", users.get(0).getFirstName());
                intent.setParam("lastName", users.get(0).getLastName());
                present(new HomePageAbilitySlice(), intent);
            }
        }

    }

    private void validateEmail(String input) {
        if (input==null){
            return;
        }
        else if(!input.contains("@") || !input.contains(".com")){
            emailError.setVisibility(Component.VISIBLE);
        }
        else{
            emailError.setVisibility(Component.HIDE);
        }
    }

    @Override
    protected void onBackground() {
        super.onBackground();
        emailField.setText("");
        passwordField.setText("");
        emailError.setVisibility(Component.HIDE);
    }
}
